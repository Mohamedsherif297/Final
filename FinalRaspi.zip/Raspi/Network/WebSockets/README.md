# WebSocket Streaming System

Real-time video and audio streaming for the Surveillance Car via WebSocket.

## Features

- ✅ **Real-time video streaming** (JPEG encoded, 640×480 @ 20 FPS)
- ✅ **Real-time audio streaming** (16-bit PCM @ 16 kHz mono)
- ✅ **Multi-client support** (broadcast to multiple dashboards)
- ✅ **MQTT-WebSocket bridge** (bidirectional communication)
- ✅ **Low latency** (backpressure control, frame dropping)
- ✅ **WAN ready** (port forwarding, reverse proxy support)
- ✅ **Configurable** (all settings via environment variables)

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    WebSocket Server                         │
│  - Multi-client broadcast                                   │
│  - Per-client queues with backpressure                      │
│  - MQTT bridge                                              │
└─────────────────────────────────────────────────────────────┘
         ↑                    ↑                    ↑
         │                    │                    │
    Video Stream         Audio Stream         MQTT Bridge
    (JPEG frames)        (PCM chunks)         (JSON messages)
         │                    │                    │
         ↓                    ↓                    ↓
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│ VideoStreamHandler│  │   AudioSystem    │  │  MQTT Broker     │
│ - OpenCV capture  │  │ - PyAudio capture│  │  - Commands      │
│ - JPEG encoding   │  │ - PCM streaming  │  │  - Status        │
└──────────────────┘  └──────────────────┘  └──────────────────┘
```

## Files

- **`config.py`** - Centralized configuration (all tunable values)
- **`websocket_server.py`** - Core async WebSocket server
- **`video_stream_handler.py`** - Video capture and streaming
- **`audio_system.py`** - Audio capture and streaming
- **`__init__.py`** - Package initialization

## Configuration

All settings can be overridden via environment variables:

### WebSocket Server
```bash
WS_HOST=0.0.0.0              # Bind address (0.0.0.0 = all interfaces)
WS_PORT=8765                 # WebSocket port
WS_PING_INTERVAL=20          # Keep-alive ping interval (seconds)
WS_PING_TIMEOUT=10           # Ping timeout (seconds)
```

### Video Settings
```bash
VIDEO_CAMERA_INDEX=0         # Camera device index (/dev/video0)
VIDEO_CAPTURE_WIDTH=640      # Capture width
VIDEO_CAPTURE_HEIGHT=480     # Capture height
VIDEO_TARGET_FPS=20          # Target frame rate
VIDEO_JPEG_QUALITY=65        # JPEG quality (0-100)
```

### Audio Settings
```bash
AUDIO_SAMPLE_RATE=16000      # Sample rate (Hz)
AUDIO_CHANNELS=1             # Number of channels (1=mono)
AUDIO_CHUNK_SAMPLES=1024     # Samples per chunk
```

### MQTT Bridge
```bash
MQTT_BROKER=localhost        # MQTT broker hostname/IP
MQTT_PORT=1883               # MQTT broker port
MQTT_TOPIC_STATUS=dev/status # Status topic
MQTT_TOPIC_MOTOR=dev/motor   # Motor control topic
```

## Usage

### Integrated Mode (Recommended)

The WebSocket system is automatically started when you run `Main.py`:

```bash
cd /home/pi/Final/Raspi
python3 Main.py
```

To disable WebSocket streaming, edit `Main.py`:
```python
ENABLE_WEBSOCKET = False
```

### Standalone Mode (Testing)

Run the WebSocket server independently:

```bash
cd /home/pi/Final/Raspi/Network/WebSockets
python3 -m websocket_server
```

Or with custom settings:
```bash
WS_PORT=9000 VIDEO_TARGET_FPS=15 python3 -m websocket_server
```

## Network Setup

### Local Network (LAN)
1. Find Raspberry Pi IP: `hostname -I`
2. Connect from browser: `ws://192.168.1.X:8765`

### Wide Area Network (WAN)

#### Option 1: Port Forwarding
1. Forward port 8765 on your router to Raspberry Pi
2. Find public IP: `curl ifconfig.me`
3. Connect: `ws://YOUR_PUBLIC_IP:8765`

#### Option 2: Reverse Proxy (Recommended)
Use nginx or caddy to terminate TLS and proxy WebSocket:

**nginx example:**
```nginx
location /ws {
    proxy_pass http://127.0.0.1:8765;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "Upgrade";
}
```

#### Firewall
```bash
sudo ufw allow 8765/tcp
# Or restrict to specific IP:
sudo ufw allow from YOUR_DASHBOARD_IP to any port 8765
```

## WebSocket Protocol

### Frame Types

All frames are prefixed with a 1-byte type tag:

| Tag | Type | Description |
|-----|------|-------------|
| `0x00` | JSON | Control/status messages |
| `0x01` | Video | JPEG encoded frame |
| `0x02` | Audio | PCM audio chunk |

### JSON Messages

**From Server:**
```json
{
  "event": "connected",
  "server": "surveillance-car"
}
```

```json
{
  "event": "mqtt",
  "topic": "dev/status",
  "payload": "online"
}
```

**From Client:**
```json
{
  "topic": "dev/motor",
  "payload": "forward"
}
```

## Client Example (JavaScript)

```javascript
const ws = new WebSocket('ws://192.168.1.100:8765');

ws.onopen = () => {
  console.log('Connected to surveillance car');
};

ws.onmessage = async (event) => {
  const data = await event.data.arrayBuffer();
  const view = new Uint8Array(data);
  const type = view[0];
  const payload = data.slice(1);
  
  if (type === 0x01) {
    // Video frame (JPEG)
    const blob = new Blob([payload], { type: 'image/jpeg' });
    const url = URL.createObjectURL(blob);
    document.getElementById('video').src = url;
  } else if (type === 0x02) {
    // Audio chunk (PCM)
    playAudio(payload);
  } else if (type === 0x00) {
    // JSON message
    const text = new TextDecoder().decode(payload);
    const msg = JSON.parse(text);
    console.log('Message:', msg);
  }
};

// Send motor command
function sendCommand(command) {
  ws.send(JSON.stringify({
    topic: 'dev/motor',
    payload: command
  }));
}
```

## Dependencies

Install on Raspberry Pi:
```bash
pip install websockets paho-mqtt opencv-python-headless pyaudio numpy
sudo apt-get install portaudio19-dev libopencv-dev
```

## Performance Tuning

### Reduce Latency
- Lower `VIDEO_TARGET_FPS` (e.g., 15 FPS)
- Reduce `VIDEO_CAPTURE_WIDTH/HEIGHT` (e.g., 320×240)
- Lower `VIDEO_JPEG_QUALITY` (e.g., 50-60)
- Reduce `AUDIO_CHUNK_SAMPLES` (e.g., 512)

### Increase Quality
- Increase `VIDEO_JPEG_QUALITY` (e.g., 80-90)
- Increase resolution (e.g., 1280×720)
- Note: Higher quality = more bandwidth + CPU

### Multi-Client Performance
- Each client gets its own queue
- Slow clients don't affect fast clients
- Frames are dropped for lagging clients (not buffered)

## Troubleshooting

### Camera not found
```bash
# List available cameras
ls -l /dev/video*

# Test camera
raspistill -o test.jpg  # For Pi Camera
ffmpeg -f v4l2 -i /dev/video0 -frames 1 test.jpg  # For USB camera
```

### Audio not working
```bash
# List audio devices
python3 -m pyaudio

# Test microphone
arecord -l
arecord -D hw:1,0 -f S16_LE -r 16000 test.wav
```

### Port already in use
```bash
# Find process using port 8765
sudo lsof -i :8765
sudo kill <PID>
```

### High CPU usage
- Reduce FPS: `VIDEO_TARGET_FPS=10`
- Reduce resolution: `VIDEO_CAPTURE_WIDTH=320 VIDEO_CAPTURE_HEIGHT=240`
- Lower JPEG quality: `VIDEO_JPEG_QUALITY=50`

## Logs

Enable debug logging:
```bash
LOG_LEVEL=DEBUG python3 Main.py
```

## Security Notes

⚠️ **Important for production:**

1. **Authentication**: Add token-based auth to WebSocket connections
2. **TLS/SSL**: Use `wss://` instead of `ws://` (via reverse proxy)
3. **Firewall**: Restrict access to known IPs only
4. **Rate limiting**: Add connection rate limits
5. **Input validation**: Validate all incoming commands

## Credits

Developed by: Kareem Radwan  
Integrated by: Surveillance Car Team  
Version: 1.0.0
