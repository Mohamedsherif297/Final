#!/usr/bin/env python3
"""
Test script for WebSocket streaming system
Tests video, audio, and MQTT bridge functionality
"""

import asyncio
import sys
from pathlib import Path

# Add parent directories to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from Network.WebSockets.websocket_server import WebSocketServer
from Network.WebSockets.video_stream_handler import VideoStreamHandler
from Network.WebSockets.audio_system import AudioSystem
from Network.WebSockets import config


async def test_websocket_system():
    """Test the complete WebSocket streaming system"""
    print("=" * 60)
    print("WebSocket Streaming System - Test")
    print("=" * 60)
    
    # Create server
    print(f"[TEST] Creating WebSocket server on ws://{config.WS_HOST}:{config.WS_PORT}")
    server = WebSocketServer(
        host=config.WS_HOST,
        port=config.WS_PORT,
        mqtt_broker=config.MQTT_BROKER,
        mqtt_port=config.MQTT_PORT,
    )
    
    # Create video handler
    print(f"[TEST] Creating video handler (camera {config.VIDEO_CAMERA_INDEX})")
    video = VideoStreamHandler(server, camera_index=config.VIDEO_CAMERA_INDEX)
    
    # Create audio handler
    print(f"[TEST] Creating audio handler")
    audio = AudioSystem(server, device_index=config.AUDIO_DEVICE_INDEX)
    
    # Start capture threads
    print("[TEST] Starting video capture...")
    video.start_capture()
    
    print("[TEST] Starting audio capture...")
    audio.start_capture()
    
    print("=" * 60)
    print("[TEST] System running. Connect with:")
    print(f"       ws://{config.WS_HOST}:{config.WS_PORT}")
    print("[TEST] Press Ctrl+C to stop")
    print("=" * 60)
    
    try:
        # Run server + streaming loops
        await asyncio.gather(
            server.start(),
            video.stream_loop(),
            audio.stream_loop(),
        )
    except (KeyboardInterrupt, asyncio.CancelledError):
        print("\n[TEST] Stopping...")
    finally:
        video.stop_capture()
        audio.stop_capture()
        print("[TEST] Test complete")


if __name__ == "__main__":
    try:
        asyncio.run(test_websocket_system())
    except KeyboardInterrupt:
        print("\n[TEST] Interrupted")
        sys.exit(0)
