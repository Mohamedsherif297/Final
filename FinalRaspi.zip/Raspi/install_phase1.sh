#!/bin/bash
# =============================================================================
#  install_phase1.sh — Surveillance Car Phase 1 Dependency Installer
#  Run this script on the Raspberry Pi before running any tests or main.py
#
#  Usage:
#    chmod +x install_phase1.sh
#    ./install_phase1.sh
#
#  What it installs:
#    System packages  → apt-get  (PortAudio, libcamera, mosquitto)
#    Python packages  → pip3     (GPIO, OpenCV, MQTT, WebSockets, pytest)
#    Pi config checks → raspi-config (camera, SSH enable check)
# =============================================================================

set -e   # exit immediately on any error

# ── Colors ────────────────────────────────────────────────────
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'  # no color

ok()   { echo -e "${GREEN}  ✓ $1${NC}"; }
info() { echo -e "${CYAN}  → $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠ $1${NC}"; }
fail() { echo -e "${RED}  ✗ $1${NC}"; }
header() {
    echo ""
    echo -e "${BOLD}${CYAN}══════════════════════════════════════════${NC}"
    echo -e "${BOLD}${CYAN}  $1${NC}"
    echo -e "${BOLD}${CYAN}══════════════════════════════════════════${NC}"
}

# ── Guard: must be run on a Pi ────────────────────────────────
header "Surveillance Car — Phase 1 Installer"
echo ""

if ! uname -m | grep -q "arm\|aarch64"; then
    warn "Not running on ARM — some packages (RPi.GPIO, pyaudio) may fail."
    warn "This script is designed for Raspberry Pi OS."
    read -rp "  Continue anyway? [y/N] " ans
    [[ "$ans" =~ ^[Yy]$ ]] || exit 1
fi

# ── Check running as non-root (but with sudo available) ──────
if [[ "$EUID" -eq 0 ]]; then
    warn "Running as root. Prefer: run as 'pi' user with sudo available."
fi

# =============================================================================
# STEP 1 — System Update
# =============================================================================
header "Step 1/5 — System Update"
info "Updating package lists..."
sudo apt-get update -qq
ok "Package lists updated"

# =============================================================================
# STEP 2 — System Packages (apt)
# =============================================================================
header "Step 2/5 — System Packages (apt)"

SYSTEM_PACKAGES=(
    # Audio (required for pyaudio / WebSocket audio streaming)
    portaudio19-dev
    python3-pyaudio

    # Camera (OpenCV + Pi Camera)
    python3-picamera2
    libcamera-apps
    libatlas-base-dev       # numpy dependency
    libjpeg-dev             # PIL/Pillow
    libopenjp2-7            # Pillow

    # OpenCV system dependencies
    libhdf5-dev
    libhdf5-serial-dev

    # MQTT broker (Mosquitto — for local broker)
    mosquitto
    mosquitto-clients

    # GPIO
    python3-rpi.gpio

    # Utilities
    python3-pip
    python3-venv
    git
)

info "Installing system packages..."
for pkg in "${SYSTEM_PACKAGES[@]}"; do
    if dpkg -s "$pkg" &>/dev/null; then
        ok "$pkg (already installed)"
    else
        info "Installing $pkg..."
        if sudo apt-get install -y -qq "$pkg" 2>/dev/null; then
            ok "$pkg"
        else
            warn "$pkg — install failed (may not be available on this OS version)"
        fi
    fi
done

# =============================================================================
# STEP 3 — Python Packages (pip)
# =============================================================================
header "Step 3/5 — Python Packages (pip3)"
info "Upgrading pip..."
python3 -m pip install --upgrade pip -q
ok "pip upgraded"

PYTHON_PACKAGES=(
    # ── Hardware ──────────────────────────────────────────────
    "RPi.GPIO>=0.7.1"
    "PyYAML>=6.0.1"

    # ── Camera / Vision ───────────────────────────────────────
    "opencv-python>=4.8.0"
    "numpy>=1.24.0"
    "Pillow>=10.0.0"

    # ── MQTT ──────────────────────────────────────────────────
    "paho-mqtt>=1.6.1"

    # ── WebSocket Streaming ───────────────────────────────────
    "websockets>=12.0"
    "pyaudio>=0.2.13"

    # ── Testing ───────────────────────────────────────────────
    "pytest>=7.4.3"
    "pytest-timeout>=2.2.0"
)

for pkg in "${PYTHON_PACKAGES[@]}"; do
    pkg_name=$(echo "$pkg" | sed 's/[>=<].*//')
    info "Installing $pkg_name..."
    if python3 -m pip install "$pkg" -q 2>/dev/null; then
        ok "$pkg_name"
    else
        warn "$pkg_name — pip install failed"
    fi
done

# =============================================================================
# STEP 4 — Raspberry Pi Configuration Checks
# =============================================================================
header "Step 4/5 — Raspberry Pi Configuration"

# Camera
info "Checking camera interface..."
if vcgencmd get_camera 2>/dev/null | grep -q "detected=1"; then
    ok "Camera detected"
elif ls /dev/video* 2>/dev/null | grep -q video; then
    ok "Camera device found: $(ls /dev/video* 2>/dev/null | head -1)"
else
    warn "Camera not detected — enable with: sudo raspi-config → Interface → Camera"
fi

# SSH
info "Checking SSH status..."
if systemctl is-active --quiet ssh; then
    ok "SSH is active"
else
    warn "SSH not running — enable with: sudo systemctl enable --now ssh"
fi

# Mosquitto (local MQTT broker)
info "Checking Mosquitto MQTT broker..."
if systemctl is-active --quiet mosquitto; then
    ok "Mosquitto is running (port 1883)"
else
    info "Starting Mosquitto..."
    sudo systemctl enable mosquitto -q
    sudo systemctl start  mosquitto
    if systemctl is-active --quiet mosquitto; then
        ok "Mosquitto started"
    else
        warn "Could not start Mosquitto — check: sudo systemctl status mosquitto"
    fi
fi

# GPIO group
info "Checking GPIO permissions..."
if groups "$USER" | grep -q gpio; then
    ok "User '$USER' is in gpio group"
else
    warn "User '$USER' not in gpio group — fixing..."
    sudo usermod -a -G gpio "$USER"
    warn "Log out and back in for gpio group to take effect"
fi

# Video group (camera access)
info "Checking video permissions..."
if groups "$USER" | grep -q video; then
    ok "User '$USER' is in video group"
else
    sudo usermod -a -G video "$USER"
    warn "Added to video group — log out and back in"
fi

# WebSocket port
info "Checking port 8765 (WebSocket)..."
if sudo ufw status 2>/dev/null | grep -q "8765"; then
    ok "Port 8765 already allowed in ufw"
else
    if sudo ufw status 2>/dev/null | grep -q "Status: active"; then
        sudo ufw allow 8765/tcp -q
        ok "Port 8765 opened in ufw"
    else
        ok "ufw not active — port 8765 accessible"
    fi
fi

# MQTT port
info "Checking port 1883 (MQTT)..."
if sudo ufw status 2>/dev/null | grep -q "Status: active"; then
    sudo ufw allow 1883/tcp -q
    ok "Port 1883 opened in ufw"
else
    ok "ufw not active — port 1883 accessible"
fi

# =============================================================================
# STEP 5 — Verify Imports
# =============================================================================
header "Step 5/5 — Verifying Python Imports"

verify_import() {
    local module=$1
    local label=${2:-$1}
    if python3 -c "import $module" 2>/dev/null; then
        ok "$label"
    else
        fail "$label — import failed (check pip install output above)"
    fi
}

verify_import "RPi.GPIO"           "RPi.GPIO      (hardware control)"
verify_import "yaml"               "PyYAML        (configuration)"
verify_import "cv2"                "OpenCV        (camera / vision)"
verify_import "numpy"              "NumPy         (array operations)"
verify_import "PIL"                "Pillow        (image processing)"
verify_import "paho.mqtt.client"   "paho-mqtt     (MQTT communication)"
verify_import "websockets"         "websockets    (WebSocket streaming)"
verify_import "pyaudio"            "PyAudio       (audio streaming)"
verify_import "pytest"             "pytest        (test runner)"

# =============================================================================
# DONE
# =============================================================================
header "Installation Complete"
echo ""
echo -e "  ${BOLD}Phase 1 packages installed.${NC}"
echo ""
echo -e "  ${CYAN}Next steps:${NC}"
echo ""
echo -e "  ${BOLD}1. Run unit tests (no main.py needed):${NC}"
echo -e "     cd /home/pi/Final/Raspi"
echo -e "     pytest tests/unit/ -v -m \"not hardware\"   # software checks only"
echo -e "     pytest tests/unit/ -v                      # full hardware tests"
echo ""
echo -e "  ${BOLD}2. Start the full system:${NC}"
echo -e "     cd /home/pi/Final/Raspi"
echo -e "     python3 main.py"
echo ""
echo -e "  ${BOLD}3. Run network tests (while main.py is running):${NC}"
echo -e "     pytest tests/network/test_mqtt.py -v"
echo -e "     pytest tests/network/test_websocket.py -v"
echo ""
echo -e "  ${BOLD}4. HiveMQ WAN test (export credentials first):${NC}"
echo -e "     export HIVEMQ_HOST=\"your-broker.s1.eu.hivemq.cloud\""
echo -e "     export HIVEMQ_USER=\"your-username\""
echo -e "     export HIVEMQ_PASS=\"your-password\""
echo -e "     pytest tests/network/test_mqtt.py -v -k \"wan\""
echo ""
echo -e "  ${BOLD}5. Combined pipeline tests:${NC}"
echo -e "     pytest tests/combined/ -v"
echo ""
echo -e "  ${YELLOW}⚠  If you were added to gpio/video groups, log out and back in first.${NC}"
echo ""
