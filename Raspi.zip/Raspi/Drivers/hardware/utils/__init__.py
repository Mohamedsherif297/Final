"""Hardware utilities module"""
