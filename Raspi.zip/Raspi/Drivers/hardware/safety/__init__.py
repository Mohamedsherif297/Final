"""Safety system module"""
