"""Motor control module"""
