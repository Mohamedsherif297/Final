"""Hardware control layer"""
