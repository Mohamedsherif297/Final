"""Servo control module"""
